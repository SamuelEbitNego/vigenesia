## CARA INSTALL Project INI

1. Repo Project ini -> Masukkan Ke Folder ' htdocs ' Masing - Masing
2. Setelah itu bikin satu database baru di phpmyadmin, Bebas mau apa aja .. Jangan lupa pada "database.php" Disetting dlu nama DB kalian yang tadi dibuat Apa
3. Abis itu install Query pada Folder ini "peers.sql" 
4. Setelah Itu, Selamat Beroprak Aprik




API List Sementara : <br/> <br/>

GET : /api/user  -> Untuk Mengambil List disaat Login <br/>
POST : /api/registrasi -> Untuk User baru yang Registrasi, Jika sudah nanti masuk ke /api/user <br/>
POST : /api/login -> Untuk Login User yang sudah registrasi
